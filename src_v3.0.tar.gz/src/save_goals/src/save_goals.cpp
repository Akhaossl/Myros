#include "ros/ros.h"
#include "std_msgs/String.h"
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Header.h>
#include <geometry_msgs/Point.h>
#include <vector>
#include <iostream>
using namespace std;
 //二维点坐标
struct Node
	{	
		float point_x;
		float point_y;
	};
vector<Node> vecNode;
int i=0;
void waypointCallback(const geometry_msgs::PointStampedConstPtr& waypoint)
{
  Node temp;
  temp.point_x=waypoint->point.x;
  temp.point_y=waypoint->point.y;
  vecNode.push_back(temp);//尾插
  //在屏幕上打印publish point
  ROS_INFO("pose show start!");
  ROS_INFO("pose is %f ,%f", vecNode[i].point_x,vecNode[i].point_y);
  i++;//只用来标记打印顺序
}
 
int main(int argc, char** argv)
{
    ros::init(argc,argv,"save_pose");
    ros::NodeHandle nh;
    ros::Subscriber waypoint_sub_ = nh.subscribe("/clicked_point", 10, waypointCallback);
    ros::spin();
    return 0;
}
