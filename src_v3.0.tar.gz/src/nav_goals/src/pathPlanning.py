#-*- coding: utf-8 -*-

import map
import math

#import matplotlib.pyplot as plt

class pathPlanning:
    def __init__(self,distanceK,angleK):
        self.__mapCreater(distanceK,angleK)
        self.__target = [[], [1, 2], [3, 4, 5], [14, 7], [9, 10], [11, 12, 13], [17, 18], [19, 20, 21], [22, 23, 24], [25, 26],
                  [27, 28, 29, 30], [14, 15, 16]]
        self.__pointXY=[[0,0],[1.0,9.75],[5.7,9.75],[11.65,9.75],[16.0,9.75],[16.0,4.15698],[16.0,0.75],[9.3,0.75],[3.85,0.75],[1.0,0.75],[7.57895,5.05263],[9.55610,7.33396]]
        self.__point3=[10.47606,8.39545]
        self.__pointKey=[[0,0],[1,2],[1,9],[2,3],[2,10],[2,1],[3,4],[3,11],[3,2],[4,3],[4,5],[5,4],[5,6],[5,11],[11,3],[11,5],[11,10],[6,5],[6,7],[7,6],[7,10],[7,8],[8,7],[8,10],[8,9],[9,8],[9,1],[10,2],[10,11],[10,7],[10,8]]

    # 搜索最优路径，输出方向
    def findBestPathToDirection(self,startDirection,mastPass,end):
        self.__bestPath = []
        self.__bestPathCost = float('inf')

        endDirction = self.__target[end]
        mastPassDirection = []

        for i in mastPass:
            mastPassDirection.append(self.__target[i])

        lastDirectionList = [0] * 100
        lastDirectionList[0] = startDirection
        self.__findBestPathFunc(lastDirectionList, 0, 0, mastPassDirection, endDirction)
        for i in range(len(self.__bestPath)-1):
            if self.__bestPath[i]==self.__bestPath[i+1]:
                self.__bestPath.pop(i)
        return  self.__pathTranslater(self.__bestPath)

    # 搜索最优路径，输出插值坐标
    def findBestPathToCoordinate(self,resolution,startDirection,mastPass,end):
        path=self.findBestPathToDirection(startDirection,mastPass,end)
        pathEnd=path[-1]
        path=path[:-1]
        pathCoordinate=[]
        for i in path:
            point=self.__pathInterpolation(self.__pointXY[self.__pointKey[i][0]], self.__pointXY[self.__pointKey[i][1]], resolution)
            pathCoordinate=pathCoordinate+point
        if end==3:
            if pathEnd==14:
                pathCoordinate=pathCoordinate+self.__pathInterpolation(self.__pointXY[self.__pointKey[14][0]],self.__point3,resolution)
            else:
                pathCoordinate = pathCoordinate + self.__pathInterpolation(self.__pointXY[self.__pointKey[7][0]], self.__point3,resolution)
        return pathCoordinate

    # 搜索最优路径，仅输出节点处坐标
    def findBestPathToCoordinateOnlyTarget(self, startDirection, mastPass, end):
        path = self.findBestPathToDirection(startDirection, mastPass, end)
        pathEnd = path[-1]
        path = path[:-1]
        pathCoordinate = []
        for i in path:
            point = self.__pointXY[self.__pointKey[i][1]]
            pathCoordinate.append(point)
        if end == 3:
            pathCoordinate.append(self.__point3)
        return pathCoordinate

    # 坐标插值函数
    def __pathInterpolation(self,start,end,resolution):
        if start[0]==end[0]:
            if end[1]>start[1]:
                afPath=[]
                y=start[1]
                while end[1]-y>resolution:
                    x=(y-start[1])/(end[1]-start[1])*(end[0]-start[0])+start[0]
                    afPath.append([x,y])
                    y=y+resolution
                return afPath
            else:
                afPath = []
                y = start[1]
                while y - end[1]> resolution:
                    x = (y - start[1]) / (end[1] - start[1]) * (end[0] - start[0]) + start[0]
                    afPath.append([x, y])
                    y = y - resolution
                return afPath
        elif end[0]>start[0]:
            resolution = resolution * math.cos(math.atan((start[1]-end[1])/(start[0]-end[0])))
            afPath=[]
            x = start[0]
            while end[0] - x > resolution:
                y =(x-start[0])/(end[0]-start[0])*(end[1]-start[1])+start[1]
                afPath.append([x,y])
                x=x+resolution
            return afPath
        else:
            resolution = resolution * math.cos(math.atan((start[1] - end[1]) / (start[0] - end[0])))
            afPath = []
            x = start[0]
            while x-end[0] > resolution:
                y = (x - start[0]) / (end[0] - start[0]) * (end[1] - start[1]) + start[1]
                afPath.append([x, y])
                x = x - resolution
            return afPath

    # 嵌套搜索函数
    def __findBestPathFunc(self,lastDirection, lastDirectionLen, lastDirectionCost, mastPass, end):
        if len(mastPass) == 0:
            for i in end:
                lastDirectionCostEnd = lastDirectionCost + self.__pathK[lastDirection[lastDirectionLen]][i]
                if lastDirectionCostEnd< self.__bestPathCost:
                    lastDirection[lastDirectionLen + 1] = i
                    self.__bestPath = lastDirection[0:lastDirectionLen + 2]
                    self.__bestPathCost = lastDirectionCostEnd
        else:
            for i in range(len(mastPass)):
                for j in mastPass[i]:
                    if lastDirectionCost + self.__pathK[lastDirection[lastDirectionLen]][j] > self.__bestPathCost:
                        continue
                    lastDirection[lastDirectionLen + 1] = j
                    self.__findBestPathFunc(lastDirection, lastDirectionLen + 1,
                                 lastDirectionCost + self.__pathK[lastDirection[lastDirectionLen]][j],
                                 mastPass[0:i] + mastPass[i + 1:], end)

    # 创建代价地图
    def __mapCreater(self,distanceK,angleK):
        dMap=map.dMap
        aMap=map.aMap
        # 生成COST地图
        hybridMap = [[0] * 31 for _ in range(31)]
        for i in range(31):
            for j in range(31):
                hybridMap[i][j] = dMap[i][j] * distanceK + aMap[i][j] * angleK

        # 使用dijkstra算法生成两点间最短路径
        self.__path = [[0] * 31 for _ in range(31)]
        self.__pathK = [[0] * 31 for _ in range(31)]
        for i in range(30):
            self.__pathK[i + 1], self.__path[i + 1] = self.__dijkstra(hybridMap, i + 1)

    # 奇怪的算法
    def __dijkstra(self,map, start):
        T = [0] * 31
        dis = [float("inf")] * 31
        disDel = [1] * 31
        dis[start] = 0
        path = [-1] * 31
        key = 30
        while key != 0:
            num = dis.index(min(dis))
            T[num] = dis[num]
            for i in range(31):
                if map[num][i] != 0:
                    if dis[i] > map[num][i] + dis[num] and disDel[i]:
                        dis[i] = map[num][i] + dis[num]
                        path[i] = num
            dis[num] = float("inf")
            disDel[num] = 0
            key = key - 1
        return T, path

    # 输出详细路径
    def __pathTranslater(self,path):
        afTransPath=[]
        for i in range(len(path)-1):
            newPath=[path[i+1]]
            while self.__path[path[i]][newPath[-1]]!=path[i]:
                newPath.append(self.__path[path[i]][newPath[-1]])
            newPath.append(path[i])
            newPath.reverse()
            afTransPath=afTransPath+newPath[:-1]
        afTransPath=afTransPath+path[-1:]
        return afTransPath

    # 使用matplotlib.pyplot显示坐标，使用时import matplotlib.pyplot as plt
    # def showPoint(self,xy):
    #     x=[]
    #     y=[]
    #     for i in xy:
    #         x.append(i[0])
    #         y.append(i[1])
    #     plt.scatter(x, y, marker='.', color='red', s=10, label='First')
    #     plt.show()
