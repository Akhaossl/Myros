#!/usr/bin/env python  
# coding=UTF-8
import rospy  
import actionlib  
from actionlib_msgs.msg import *  
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist #,PoseStamped  
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal  
from random import sample  
from math import pow, sqrt 
import geometry_msgs.msg  
class MultiNav():  
    def __init__(self):  
        rospy.init_node('MultiNav', anonymous=False)  
        rospy.on_shutdown(self.shutdown)  
        pub=rospy.Publisher('/move_base_simple_goal',geometry_msgs.msg.PoseStamped,queue_size=10)
        # How long in seconds should the robot pause at each location?  
        self.rest_time = rospy.get_param("~rest_time", 10)  
        locations = dict()  
        # 替代为自己的地图上对应的位置，朝向默认为1
        locations[0] = Pose(Point(4, 0, 0.00), Quaternion(0.000, 0.000, 0.000, 1.000))  
        locations[1] = Pose(Point(8, 0, 0.00), Quaternion(0.000, 0.000, 0.000, 1.000))  
        locations[2] = Pose(Point(10, -5, 0.00), Quaternion(0.000, 0.000, 0.000, 1.000))  
        # Subscribe to the move_base action server  
        self.move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction)  
        rospy.loginfo("Waiting for move_base action server...")  
  
        # Wait 60 seconds for the action server to become available  
        self.move_base.wait_for_server(rospy.Duration(60))  
        rospy.loginfo("Connected to move base server")  
          
        # A variable to hold the initial pose of the robot to be set by the user in RViz  
        initial_pose = PoseWithCovarianceStamped()  
        # Variables to keep track of success rate, running time, and distance traveled  
        n_locations = len(locations)   
        i = n_locations  
        start_time = rospy.Time.now()    
        rospy.loginfo("Starting navigation test")  
        i=0
        self.goal = MoveBaseGoal()  
        self.goal.target_pose.pose = locations[i]  
        self.goal.target_pose.header.frame_id = 'map'  
        self.goal.target_pose.header.stamp = rospy.Time.now() 
    # #Test to publish geometry_msgs
        msg=geometry_msgs.msg.PoseStamped()  
        msg.header.frame_id='map'
        msg.header.stamp=rospy.Time.now()
        msg.pose=locations[i]
        self.move_base.send_goal(self.goal, done_cb=None, active_cb=active_cb, feedback_cb=self.feedback_cb)
        pub.publish(msg)
    # #end Test
        rospy.loginfo("Going to: " + str(i)) 
        dist=self.distances(current_point)
        i += 1            
        # Start the robot toward the next location  
        
        # Begin the main loop and run through a sequence of locations  
        while not i == n_locations and not rospy.is_shutdown():  
            dist=self.distances(current_point)
            if dist<0.6:
            # Set up the next goal location  
                self.goal = MoveBaseGoal()  
                self.goal.target_pose.pose = locations[i]  
                self.goal.target_pose.header.frame_id = 'map'  
                self.goal.target_pose.header.stamp = rospy.Time.now()  
                # Let the user know where the robot is going next  
                rospy.loginfo("Going to: " + str(i)) 
            # #set up /move_base_simple/goal
                msg=geometry_msgs.msg.PoseStamped()
                msg.header.frame_id='map'
                msg.header.stamp=rospy.Time.now()
                msg.pose=locations[i]
                self.move_base.send_goal(self.goal, done_cb=None, active_cb=active_cb, feedback_cb=self.feedback_cb)
                pub.publish(msg)
            # #end send
                i += 1            
                # Start the robot toward the next location  
                  
 
  
    def update_initial_pose(self, initial_pose):  
        self.initial_pose = initial_pose  
    def distances(self,current_point):
        rospy.loginfo("start computer")
        dis=sqrt(pow(current_point.x-self.goal.target_pose.pose.position.x,2)+pow(current_point.y-self.goal.target_pose.pose.position.y,2))
        rospy.loginfo(dis)
        return dis
    def shutdown(self):  
        rospy.loginfo("Stopping the robot...")  
        self.move_base.cancel_goal()  
        rospy.sleep(2)  
        self.cmd_vel_pub.publish(Twist())  
        rospy.sleep(1)
    def feedback_cb(self,msg):
        current_point.x=msg.base_position.pose.position.x
        current_point.y=msg.base_position.pose.position.y
        current_point.z=msg.base_position.pose.position.z
        rospy.loginfo(current_point)
        
def active_cb():
    rospy.loginfo("active callback")
def trunc(f, n):  
    # Truncates/pads a float f to n decimal places without rounding  
    slen = len('%.*f' % (n, f))  
    return float(str(f)[:slen])  
  
if __name__ == '__main__':  
    try:  
        current_point=Point(100, 100, 100)
        global current_point
        MultiNav()  
        rospy.spin()  
    except rospy.ROSInterruptException:  
        rospy.loginfo("AMCL navigation test finished.")  
